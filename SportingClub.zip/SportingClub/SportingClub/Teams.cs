﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompusSportingTeams
{
    public class Teams : Sporting
    {
        public string location;
        public string personToContact;

        public Teams()
            : base()
        {
        }

        public Teams(string sName, string cName, string loc, string PTC)
                : base(sName, cName)
        {
            location = loc;
            personToContact = PTC;
        }

        public string Location
        {
            get
            {
                return location;
            }
        }
        public string PersonToContact
        {
            get
            {
                return personToContact;
            }
        }

        public override string GetPracticeSchedule()
        {
            return "BasketBall practice is every Monday To Wednesday";
        }
        public override string ToString()
        {
            return base.ToString() + 
                "\n Location: " + location + 
                " \nPerson to Contact: " + personToContact;
        }
    }
}
