﻿namespace SportingClub
{
    public class Sporting
    {
        public string sportName;
        public string coachName;

        public Sporting(string sName, string cName)
        {
            sportName = sName;
            coachName = cName;
        }

        public Sporting()
        {
        }

        public string SportName
        {
            get
            {
                return sportName;
            }
            set
            {
                sportName = value;
            }
        }
        public string CoachName
        {
            get
            {
                return coachName;
            }
            set
            {
                coachName = value;
            }
        }
        public override string ToString()
        {
            return "Sport: " + sportName + "\nCoach: " + coachName;
        }
        public virtual string GetPracticeSchedule()
        {
            return "Practice schedule is not available";
        }
    }
}
}
