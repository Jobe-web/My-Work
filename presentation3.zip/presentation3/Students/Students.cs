﻿namespace Students
{
    public class Students
    {
        protected string studentNumber;
        protected string studentName;
        protected string course;

        public Students(string sNumber, string sName, string course)
        {
            studentNumber = sNumber;
            studentName = sName;
            this.course = course;
        }
        public string StudentNumber
        {
            get
            {
                return studentNumber;
            }
        }
        public string StudentName
        {
            get
            {
                return studentName;
            }
        }
        public string Course
        {
            get
            {
                return course;
            }
            set
            {
                course = value;
            }
        }
        public virtual string IoString()
        {
            return "Student Number: " + studentNumber +
                "Student Name: " + studentName +
                "Course: " + course;
        }

    }
}
