﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    public class UndergraduateStudent: Students
    {
        public string classification;
        public string guardianName;
        public string guardianAddress;

        public UndergraduateStudent(string sNumber, string sName, string course, string classif, string gName, string gAddress)
            :base(sNumber, sName, course)
        {
            classification = classif;
            guardianName = gName;
            guardianAddress = gAddress;
        }
        public string Classification
        {
            get
            {
                return classification;
            }
            set
            {
                classification = value;
            }
        }
        public string GuadianName
        {
            get
            {
                return guardianName;
            }
            set
            {
                guardianName = value;
            }
        }
        public string GuardianAddress
        {
            get
            {
                return guardianAddress;
            }
            set
            {
                guardianAddress = value;
            }
        }
        public override string ToString()
        {
            return base.ToString() + "Classifications: " + classification +
                "Guardian Name: " + guardianName + "Guardian Address: " + guardianAddress;
        }

    }
}
