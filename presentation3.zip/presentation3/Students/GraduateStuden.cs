﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    public class GraduateStudent: Students
    {
        public string degreeAwarded;
        public string locationInstitution;

        public GraduateStudent(string sNumber, string sName, string course, string degreeA, string location)
            :base(sNumber, sName, course)
        {
            degreeAwarded = degreeA;
            locationInstitution = location;
        }

        public string DegreeAwarded
        {
            get
            {
                return degreeAwarded;
            }
            set
            {
                degreeAwarded= value;
            }
        }
        public string LocationInstitution
        {
            get
            {
                return locationInstitution;
            }
            set
            {
                locationInstitution= value;
            }
        }
        public override string ToString()
        {
            return base.ToString() + "Degree Awarded: " + degreeAwarded +
                "Institution Location: " + locationInstitution;
        }
    }
}
