using Students;

namespace presentation3
{
    public partial class Form1 : Form
    {
        public GraduateStudent gStudents;
        public UndergraduateStudent UnderGStudents;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gStudents = new GraduateStudent("22356744", "S Mtshali", "Office Management and Technology", "OMT", "Umlazi D, Durban, KwaZulu-Natal, South Africa");
            UnderGStudents = new UndergraduateStudent("22552331", "L.S Jobe", "Information Technology and Communication", "sophomore", "Miss T Maseko", "Richards Bay, Nseleni,Mazimazane");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtsName.Text = gStudents.StudentName.ToString();
            txtsNumber.Text = gStudents.StudentNumber.ToString();
            txtcourse.Text = gStudents.Course.ToString();

            txtDawarded.Text = gStudents.DegreeAwarded.ToString();
            txtLocation.Text = gStudents.LocationInstitution.ToString();

            txtClassif.Clear();
            txtgName.Clear();
            txtgAddress.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtsName.Text = UnderGStudents.StudentName.ToString();
            txtsNumber.Text = UnderGStudents.StudentNumber.ToString();
            txtcourse.Text = UnderGStudents.Course.ToString();

            txtClassif.Text = UnderGStudents.Classification.ToString();
            txtgName.Text = UnderGStudents.GuadianName.ToString();
            txtgAddress.Text = UnderGStudents.GuardianAddress.ToString();
            txtDawarded.Clear();
            txtLocation.Clear();
        }
    }
}
