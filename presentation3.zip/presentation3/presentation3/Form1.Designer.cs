﻿namespace presentation3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtcourse = new TextBox();
            txtsName = new TextBox();
            txtsNumber = new TextBox();
            txtDawarded = new TextBox();
            txtClassif = new TextBox();
            txtgAddress = new TextBox();
            txtgName = new TextBox();
            label8 = new Label();
            label9 = new Label();
            txtLocation = new TextBox();
            label10 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Chartreuse;
            button1.Location = new Point(482, 84);
            button1.Name = "button1";
            button1.Size = new Size(75, 43);
            button1.TabIndex = 0;
            button1.Text = "Graduated";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Chartreuse;
            button2.Location = new Point(483, 160);
            button2.Name = "button2";
            button2.Size = new Size(75, 44);
            button2.TabIndex = 1;
            button2.Text = "UnderGraduated";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 18F, FontStyle.Bold);
            label1.Location = new Point(179, 22);
            label1.Name = "label1";
            label1.Size = new Size(232, 29);
            label1.TabIndex = 3;
            label1.Text = "MUT DISPLAYER";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label2.Location = new Point(32, 87);
            label2.Name = "label2";
            label2.Size = new Size(115, 15);
            label2.TabIndex = 4;
            label2.Text = "Student Number :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label3.Location = new Point(32, 138);
            label3.Name = "label3";
            label3.Size = new Size(100, 15);
            label3.TabIndex = 5;
            label3.Text = "Student Name :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label4.Location = new Point(32, 189);
            label4.Name = "label4";
            label4.Size = new Size(55, 15);
            label4.TabIndex = 6;
            label4.Text = "Course :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label5.Location = new Point(32, 237);
            label5.Name = "label5";
            label5.Size = new Size(113, 15);
            label5.TabIndex = 7;
            label5.Text = "Degree Awarded :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label6.Location = new Point(32, 279);
            label6.Name = "label6";
            label6.Size = new Size(93, 15);
            label6.TabIndex = 8;
            label6.Text = "Classification :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label7.Location = new Point(28, 465);
            label7.Name = "label7";
            label7.Size = new Size(116, 15);
            label7.TabIndex = 9;
            label7.Text = "Guadian Address :";
            // 
            // txtcourse
            // 
            txtcourse.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtcourse.Location = new Point(152, 186);
            txtcourse.Name = "txtcourse";
            txtcourse.Size = new Size(308, 23);
            txtcourse.TabIndex = 10;
            // 
            // txtsName
            // 
            txtsName.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtsName.Location = new Point(152, 135);
            txtsName.Name = "txtsName";
            txtsName.Size = new Size(308, 23);
            txtsName.TabIndex = 11;
            // 
            // txtsNumber
            // 
            txtsNumber.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtsNumber.Location = new Point(152, 84);
            txtsNumber.Name = "txtsNumber";
            txtsNumber.Size = new Size(308, 23);
            txtsNumber.TabIndex = 12;
            // 
            // txtDawarded
            // 
            txtDawarded.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtDawarded.Location = new Point(152, 234);
            txtDawarded.Name = "txtDawarded";
            txtDawarded.Size = new Size(405, 23);
            txtDawarded.TabIndex = 13;
            // 
            // txtClassif
            // 
            txtClassif.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtClassif.Location = new Point(152, 277);
            txtClassif.Name = "txtClassif";
            txtClassif.Size = new Size(405, 23);
            txtClassif.TabIndex = 14;
            // 
            // txtgAddress
            // 
            txtgAddress.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtgAddress.Location = new Point(31, 483);
            txtgAddress.Name = "txtgAddress";
            txtgAddress.Size = new Size(526, 23);
            txtgAddress.TabIndex = 15;
            // 
            // txtgName
            // 
            txtgName.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtgName.Location = new Point(31, 439);
            txtgName.Name = "txtgName";
            txtgName.Size = new Size(526, 23);
            txtgName.TabIndex = 17;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Georgia", 18F, FontStyle.Bold);
            label8.Location = new Point(193, 371);
            label8.Name = "label8";
            label8.Size = new Size(188, 29);
            label8.TabIndex = 18;
            label8.Text = "Guardian Info";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label9.Location = new Point(28, 421);
            label9.Name = "label9";
            label9.Size = new Size(108, 15);
            label9.TabIndex = 19;
            label9.Text = "Guardian Name :";
            // 
            // txtLocation
            // 
            txtLocation.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtLocation.Location = new Point(31, 334);
            txtLocation.Name = "txtLocation";
            txtLocation.Size = new Size(526, 23);
            txtLocation.TabIndex = 20;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label10.Location = new Point(28, 316);
            label10.Name = "label10";
            label10.Size = new Size(133, 15);
            label10.TabIndex = 21;
            label10.Text = "Institution Location :";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Chartreuse;
            ClientSize = new Size(589, 518);
            Controls.Add(label10);
            Controls.Add(txtLocation);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(txtgName);
            Controls.Add(txtgAddress);
            Controls.Add(txtClassif);
            Controls.Add(txtDawarded);
            Controls.Add(txtsNumber);
            Controls.Add(txtsName);
            Controls.Add(txtcourse);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtcourse;
        private TextBox txtsName;
        private TextBox txtsNumber;
        private TextBox txtDawarded;
        private TextBox txtClassif;
        private TextBox txtgAddress;
        private TextBox txtgName;
        private Label label8;
        private Label label9;
        private TextBox txtLocation;
        private Label label10;
    }
}
