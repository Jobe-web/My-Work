using Sporting;

namespace CampusSportClub
{
    public partial class Form1 : Form
    {
        private Teams ateams;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShowInfo_Click(object sender, EventArgs e)
        {
            txtsName.Text = ateams.ToString();
            txtcName.Text = ateams.ToString();
            txtCL.Text = ateams.ToString();
            txtPTC.Text = ateams.ToString();
            txtPS.Text = ateams.ToString();
        }
    }
}
