﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sporting
{
    public class Teams : Sporting
    {
        private string courtLoc;
        private string personToContact;

        public Teams()
            :base()
        {

        }

    public Teams(string sName, string cName,string CL, string PTC)
            :base(sName, cName)
        {
            courtLoc = CL;
            personToContact = PTC;
        }

    }
}
