﻿namespace Sporting
{
    public class Sporting
    {
        private string sportName;
        private string coachName;

    public Sporting
        {

        }

    public Sporting(string sName, string cName)
        {
            sportName = sName;
            coachName = cName;

        }

        public Sporting()
        {
        }

        public string SportName
        {
            get
            {
                return sportName;
            }
            set
            {
                sportName = value;
            }
        }
        public string CoachName
        {
            get
            {
                return coachName;
            }
            set
            {
                coachName = value;
            }
        }
        public override string ToString()
        {
            return "Sport Name: "+sportName+
                "\nCoach Name: "+coachName;
        }
        public virtual string GetPracticeS()
        {
            return "No prictice available right now.";
        }
    }
}
