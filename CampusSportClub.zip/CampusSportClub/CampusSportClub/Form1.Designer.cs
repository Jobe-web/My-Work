﻿namespace CampusSportClub
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtsName = new TextBox();
            txtcName = new TextBox();
            txtCL = new TextBox();
            txtPS = new TextBox();
            btnShowInfo = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtPTC = new TextBox();
            label6 = new Label();
            SuspendLayout();
            // 
            // txtsName
            // 
            txtsName.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtsName.Location = new Point(120, 60);
            txtsName.Name = "txtsName";
            txtsName.Size = new Size(234, 23);
            txtsName.TabIndex = 0;
            // 
            // txtcName
            // 
            txtcName.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtcName.Location = new Point(120, 110);
            txtcName.Name = "txtcName";
            txtcName.Size = new Size(234, 23);
            txtcName.TabIndex = 1;
            // 
            // txtCL
            // 
            txtCL.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtCL.Location = new Point(254, 176);
            txtCL.Name = "txtCL";
            txtCL.Size = new Size(224, 23);
            txtCL.TabIndex = 2;
            // 
            // txtPS
            // 
            txtPS.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtPS.Location = new Point(21, 289);
            txtPS.Name = "txtPS";
            txtPS.Size = new Size(457, 23);
            txtPS.TabIndex = 3;
            // 
            // btnShowInfo
            // 
            btnShowInfo.FlatStyle = FlatStyle.Flat;
            btnShowInfo.Location = new Point(21, 193);
            btnShowInfo.Name = "btnShowInfo";
            btnShowInfo.Size = new Size(75, 46);
            btnShowInfo.TabIndex = 4;
            btnShowInfo.Text = "Show Info";
            btnShowInfo.UseVisualStyleBackColor = true;
            btnShowInfo.Click += btnShowInfo_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label1.Location = new Point(11, 60);
            label1.Name = "label1";
            label1.Size = new Size(85, 15);
            label1.TabIndex = 5;
            label1.Text = "Sport Name :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label2.Location = new Point(11, 118);
            label2.Name = "label2";
            label2.Size = new Size(87, 15);
            label2.TabIndex = 6;
            label2.Text = "Coach Name :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label3.Location = new Point(121, 179);
            label3.Name = "label3";
            label3.Size = new Size(101, 15);
            label3.TabIndex = 7;
            label3.Text = "Court Location :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label4.Location = new Point(21, 271);
            label4.Name = "label4";
            label4.Size = new Size(127, 15);
            label4.TabIndex = 8;
            label4.Text = "Practice Schadules :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Cambria", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(120, 239);
            label5.Name = "label5";
            label5.Size = new Size(121, 15);
            label5.TabIndex = 9;
            label5.Text = "Person To Contact :";
            // 
            // txtPTC
            // 
            txtPTC.Font = new Font("Cambria", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtPTC.Location = new Point(254, 236);
            txtPTC.Name = "txtPTC";
            txtPTC.Size = new Size(224, 23);
            txtPTC.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(98, 18);
            label6.Name = "label6";
            label6.Size = new Size(207, 24);
            label6.TabIndex = 11;
            label6.Text = "Campus Sport Club";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Coral;
            ClientSize = new Size(501, 324);
            Controls.Add(label6);
            Controls.Add(txtPTC);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnShowInfo);
            Controls.Add(txtPS);
            Controls.Add(txtCL);
            Controls.Add(txtcName);
            Controls.Add(txtsName);
            Name = "Form1";
            Text = "Sporting";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtsName;
        private TextBox txtcName;
        private TextBox txtCL;
        private TextBox txtPS;
        private Button btnShowInfo;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtPTC;
        private Label label6;
    }
}
