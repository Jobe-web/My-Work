namespace Person_Information_App
{
    public partial class PIA : Form
    {
        public PIA()
        {
            InitializeComponent();
            
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtSurname.Text == "" || txtEmail.Text == "" || txtPhoneN.Text == "" || cmbCountry.SelectedItem == null || cmbPhoneCode.SelectedItem == null)
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (!txtEmail.Text.Contains("@"))
            {
                MessageBox.Show("Please Enter a valid email address.");
                return;
            }
            else
            {
                MessageBox.Show("Name: " + txtName.Text + "\nSurname: " + txtSurname.Text + "\nEmail: " + txtEmail.Text +
                    "\nCountry: " + cmbCountry.SelectedItem.ToString() + "\nPhone No. : " + cmbPhoneCode.SelectedItem.ToString() + txtPhoneN.Text, "Personal Information", MessageBoxButtons.OKCancel);
            }
            txtName.Clear();
            txtSurname.Clear();
            txtEmail.Clear();
            cmbCountry.SelectedIndex = 0;
            cmbPhoneCode.SelectedIndex = 0;
            txtPhoneN.Clear();
        }

        private void cmbCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbPhoneCode.SelectedIndex = cmbCountry.SelectedIndex;
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)// this show information about the application when the user click on the about menu item
        {
            MessageBox.Show("Person Information App" +
                "\nVersion 1.0" +
                "\nDeveloped by Mr L.S Jobe", "About : This system help " +
                "to capture personal information " +
                "of the user", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Result == DialogResult.Yes)
            {

                this.Close();
            }

        }
    }
}
