﻿namespace Person_Information_App
{
    partial class PIA
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnExit = new Button();
            txtName = new TextBox();
            txtSurname = new TextBox();
            btnDisplay = new Button();
            cmbPhoneCode = new ComboBox();
            label6 = new Label();
            cmbCountry = new ComboBox();
            txtEmail = new TextBox();
            txtPhoneN = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label2 = new Label();
            label3 = new Label();
            menuStrip1 = new MenuStrip();
            helpToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem1 = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btnExit);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(txtSurname);
            panel1.Controls.Add(btnDisplay);
            panel1.Controls.Add(cmbPhoneCode);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(cmbCountry);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(txtPhoneN);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(menuStrip1);
            panel1.Location = new Point(33, 94);
            panel1.Name = "panel1";
            panel1.Size = new Size(744, 344);
            panel1.TabIndex = 0;
            // 
            // btnExit
            // 
            btnExit.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnExit.Location = new Point(657, 30);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(75, 23);
            btnExit.TabIndex = 16;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // txtName
            // 
            txtName.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            txtName.Location = new Point(141, 25);
            txtName.Name = "txtName";
            txtName.Size = new Size(247, 25);
            txtName.TabIndex = 14;
            // 
            // txtSurname
            // 
            txtSurname.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            txtSurname.Location = new Point(141, 84);
            txtSurname.Name = "txtSurname";
            txtSurname.Size = new Size(247, 25);
            txtSurname.TabIndex = 13;
            // 
            // btnDisplay
            // 
            btnDisplay.Location = new Point(191, 296);
            btnDisplay.Name = "btnDisplay";
            btnDisplay.Size = new Size(75, 23);
            btnDisplay.TabIndex = 1;
            btnDisplay.Text = "Display";
            btnDisplay.UseVisualStyleBackColor = true;
            btnDisplay.Click += btnDisplay_Click;
            // 
            // cmbPhoneCode
            // 
            cmbPhoneCode.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            cmbPhoneCode.FormattingEnabled = true;
            cmbPhoneCode.Items.AddRange(new object[] { "+27", "+1", "+1", "+44", "+91", "+86", "+81", "+234", "+254", "+263", "+260", "+20" });
            cmbPhoneCode.Location = new Point(141, 246);
            cmbPhoneCode.Name = "cmbPhoneCode";
            cmbPhoneCode.Size = new Size(61, 26);
            cmbPhoneCode.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(29, 201);
            label6.Name = "label6";
            label6.Size = new Size(72, 18);
            label6.TabIndex = 11;
            label6.Text = "Country :";
            // 
            // cmbCountry
            // 
            cmbCountry.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            cmbCountry.FormattingEnabled = true;
            cmbCountry.Items.AddRange(new object[] { "South Africa", "United States", "Canada", "United Kingdom", "India", "China", "Japan", "Nigeria", "Kenya", "Zimbawe", "Zambia", "Egypt" });
            cmbCountry.Location = new Point(141, 196);
            cmbCountry.Name = "cmbCountry";
            cmbCountry.Size = new Size(169, 26);
            cmbCountry.TabIndex = 10;
            cmbCountry.SelectedIndexChanged += cmbCountry_SelectedIndexChanged;
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            txtEmail.Location = new Point(141, 140);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(247, 25);
            txtEmail.TabIndex = 6;
            // 
            // txtPhoneN
            // 
            txtPhoneN.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            txtPhoneN.Location = new Point(208, 246);
            txtPhoneN.Name = "txtPhoneN";
            txtPhoneN.Size = new Size(180, 25);
            txtPhoneN.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            label5.Location = new Point(29, 246);
            label5.Name = "label5";
            label5.Size = new Size(90, 18);
            label5.TabIndex = 4;
            label5.Text = "Phone No. :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            label4.Location = new Point(29, 145);
            label4.Name = "label4";
            label4.Size = new Size(54, 18);
            label4.TabIndex = 3;
            label4.Text = "Email :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            label2.Location = new Point(29, 30);
            label2.Name = "label2";
            label2.Size = new Size(56, 18);
            label2.TabIndex = 1;
            label2.Text = "Name :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 11.25F, FontStyle.Bold);
            label3.Location = new Point(29, 89);
            label3.Name = "label3";
            label3.Size = new Size(79, 18);
            label3.TabIndex = 2;
            label3.Text = "Surname :";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(744, 24);
            menuStrip1.TabIndex = 15;
            menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { helpToolStripMenuItem1, aboutToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "Help";
            // 
            // helpToolStripMenuItem1
            // 
            helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            helpToolStripMenuItem1.Size = new Size(107, 22);
            helpToolStripMenuItem1.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(107, 22);
            aboutToolStripMenuItem.Text = "About";
            aboutToolStripMenuItem.Click += aboutToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Courier New", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(174, 22);
            label1.Name = "label1";
            label1.Size = new Size(414, 31);
            label1.TabIndex = 0;
            label1.Text = "Personal Information (PI)";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.images;
            pictureBox1.Location = new Point(423, 101);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(299, 163);
            pictureBox1.TabIndex = 18;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(panel1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "PIA";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label4;
        private Label label2;
        private Label label3;
        private Label label1;

        private TextBox txtEmail;
        private TextBox txtPhoneN;
        private Label label5;
        private ComboBox cmbPhoneCode;
        private Label label6;
        private ComboBox cmbCountry;
        private Button btnDisplay;
        private TextBox txtName;
        private TextBox txtSurname;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem1;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private Button btnExit;
        private PictureBox pictureBox1;
    }
}
