﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BankAccount
{
    public class Checkings : Bank
    {
        public Checkings(string aNumber, string aHolder, double bal)
        : base(aNumber, aHolder, bal)
        {

        }
        public override void Withdraw(double amount)
        {
            if(balance >= amount)
            {
                balance -= amount;
            }

        }
        public double GetBalance()
        {
            return balance;
        }
    }

}
