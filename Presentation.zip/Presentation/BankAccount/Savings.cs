﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    public class Savings : Bank
    {
        private double interestRate;
        public Savings(string aNumber, string aHolder, double bal, double intRate) 
            : base(aNumber, aHolder, bal)
        {
            interestRate = intRate;
        }

        public void AddRate()
        {
            balance += balance * interestRate;
        }

                public double GetBalance()
        {
            return balance;
        }
    }
}
