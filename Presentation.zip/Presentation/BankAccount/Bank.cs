﻿namespace BankAccount
{
    public class Bank
    {
        protected string accountNumber;
        protected string accountHolder;
        protected double balance;

        public Bank(string aNumber, string aHolder, double bal)
        {
            accountHolder = aHolder;
            accountNumber = aNumber;
            balance = bal;
        }
        public string AccountHolder
        {
            get
            {
                return accountHolder;
            }
        }
        public string AccountNumber
        {
            get
            {
                return accountNumber;
            }
        }
        public double Balance
        {
            get
            {
                return balance;
            }
        }
        public virtual void Deposit(double amount)
        {
            balance += amount;
        }
        public virtual void Withdraw(double amount)
        {
            balance -= amount;
        }
        //public virtual void Display()
        //{
            
        //}
    }
}
