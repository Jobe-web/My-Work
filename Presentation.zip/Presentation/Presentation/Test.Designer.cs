﻿namespace Presentation
{
    partial class Test
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtBalance = new TextBox();
            txtaHolder = new TextBox();
            txtANumber = new TextBox();
            button1 = new Button();
            button2 = new Button();
            label4 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label1.Location = new Point(81, 76);
            label1.Name = "label1";
            label1.Size = new Size(115, 15);
            label1.TabIndex = 0;
            label1.Text = "Account Number :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label2.Location = new Point(81, 128);
            label2.Name = "label2";
            label2.Size = new Size(106, 15);
            label2.TabIndex = 1;
            label2.Text = "Account Holder :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            label3.Location = new Point(81, 189);
            label3.Name = "label3";
            label3.Size = new Size(61, 15);
            label3.TabIndex = 2;
            label3.Text = "Balance :";
            // 
            // txtBalance
            // 
            txtBalance.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtBalance.Location = new Point(215, 181);
            txtBalance.Name = "txtBalance";
            txtBalance.Size = new Size(234, 23);
            txtBalance.TabIndex = 3;
            // 
            // txtaHolder
            // 
            txtaHolder.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtaHolder.Location = new Point(215, 120);
            txtaHolder.Name = "txtaHolder";
            txtaHolder.Size = new Size(234, 23);
            txtaHolder.TabIndex = 4;
            // 
            // txtANumber
            // 
            txtANumber.Font = new Font("Cambria", 9.75F, FontStyle.Bold);
            txtANumber.Location = new Point(215, 68);
            txtANumber.Name = "txtANumber";
            txtANumber.Size = new Size(234, 23);
            txtANumber.TabIndex = 5;
            // 
            // button1
            // 
            button1.BackColor = Color.Aqua;
            button1.Location = new Point(140, 248);
            button1.Name = "button1";
            button1.Size = new Size(75, 47);
            button1.TabIndex = 6;
            button1.Text = "Show Checkings";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.CornflowerBlue;
            button2.Location = new Point(344, 248);
            button2.Name = "button2";
            button2.Size = new Size(75, 47);
            button2.TabIndex = 7;
            button2.Text = "Show Savings";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Georgia", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(140, 9);
            label4.Name = "label4";
            label4.Size = new Size(186, 29);
            label4.TabIndex = 8;
            label4.Text = "Bank Account";
            // 
            // Test
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Coral;
            ClientSize = new Size(503, 335);
            Controls.Add(label4);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtANumber);
            Controls.Add(txtaHolder);
            Controls.Add(txtBalance);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Test";
            Text = "Bank";
            Load += Test_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtBalance;
        private TextBox txtaHolder;
        private TextBox txtANumber;
        private Button button1;
        private Button button2;
        private Label label4;
    }
}
