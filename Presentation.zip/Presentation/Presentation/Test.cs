using BankAccount;

namespace Presentation
{
    public partial class Test : Form
    {
        public Checkings check;
        public Savings sav;
        public Test()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtANumber.Text = check.AccountNumber;
            txtaHolder.Text = check.AccountHolder;
            check.Withdraw(2000);
            txtBalance.Text = check.GetBalance().ToString();
        }

        private void Test_Load(object sender, EventArgs e)
        {
            check = new Checkings("1934579712", "L.S Jobe", 4000);
            sav = new Savings("1934579712", "L.S Jobe", 10000, 0.15);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtANumber.Text = sav.AccountNumber;
            txtaHolder.Text = sav.AccountHolder;
            sav.Deposit(2000);
            sav.Withdraw(500);
            sav.AddRate();
            txtBalance.Text = sav.GetBalance().ToString();
        }
    }
}
