﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lindoStudent
{
    internal class Program
    {
        static string Name;
        static string StudentNo;
        static double mark1, mark2, mark3;
        static double avg;
        static void Main(string[] args)
        {
            int choice = 0;
            while (choice != 5)//loop to display the menu until the user chooses to exit
            {
                Console.WriteLine("========student menu=======");
                Console.WriteLine("1. Capture student details");
                Console.WriteLine("2. Calculate average mark");
                Console.WriteLine("3. determine pass/fail");
                Console.WriteLine("4 exit");
                Console.WriteLine("Choose from the above: ");
                choice = int.Parse(Console.ReadLine());

                if (choice == 1)//if the user chooses 1, call the AddStudent method to capture student details
                {
                    AddStudent();
                }
                else if (choice == 2)//if the user chooses 2, call the CalculateAverage method to calculate the average mark
                {
                    CalculateAverage();
                }
                else if (choice == 3)//if the user chooses 3, call the StudentStatus method to determine if the student has passed or failed
                {
                    StudentStatus();
                }
                else if (choice == 4)//if the user chooses 4, exit the program
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invaild choice");//if the user enters an invalid choice, display an error message
                }
            }
        }
        static void AddStudent()//methode to capture student details
        {
            Console.WriteLine("Enter your name : ");
            Name = Console.ReadLine();

            Console.WriteLine("Enter your student number : ");
             StudentNo = Console.ReadLine();

            Console.WriteLine("Enter your mark 1 : ");
             mark1 =double.Parse(Console.ReadLine());

            Console.WriteLine("Enter your mark 2 : ");
            mark2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Enter your mark 3 : ");
            mark3 = double.Parse(Console.ReadLine());
        }
        static void CalculateAverage()//methode to calculate the average mark
        {
            avg = mark1 + mark2 + mark3 / 3;
            Console.WriteLine("Average marks is:"+ avg);
        }
        static void StudentStatus()//method to determine if the student has passed or failed
        {
            if (avg >= 50)
            {
                Console.WriteLine(Name+" has Pass");
            }
            else
            {
                Console.WriteLine(Name+" has Fail");
            }
        }
    }
}
