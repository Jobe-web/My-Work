﻿
namespace YouthSportSignUp
{
    partial class YouthSport
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YouthSport));
            rbBasketball = new RadioButton();
            rbSoccer = new RadioButton();
            rbNetball = new RadioButton();
            rbSwimming = new RadioButton();
            rbRunning = new RadioButton();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            lblMessage = new Label();
            button1 = new Button();
            btnClear = new Button();
            rbVolleyball = new RadioButton();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // rbBasketball
            // 
            rbBasketball.AutoSize = true;
            rbBasketball.Font = new Font("Cambria", 11.25F, FontStyle.Bold);
            rbBasketball.Location = new Point(47, 149);
            rbBasketball.Name = "rbBasketball";
            rbBasketball.Size = new Size(101, 21);
            rbBasketball.TabIndex = 0;
            rbBasketball.Text = "BasketBall";
            rbBasketball.UseVisualStyleBackColor = true;
            rbBasketball.CheckedChanged += rbBasketball_CheckedChanged;
            // 
            // rbSoccer
            // 
            rbSoccer.AutoSize = true;
            rbSoccer.Font = new Font("Cambria", 11.25F, FontStyle.Bold);
            rbSoccer.Location = new Point(47, 192);
            rbSoccer.Name = "rbSoccer";
            rbSoccer.Size = new Size(72, 21);
            rbSoccer.TabIndex = 1;
            rbSoccer.Text = "Soccer";
            rbSoccer.UseVisualStyleBackColor = true;
            rbSoccer.CheckedChanged += rbSoccer_CheckedChanged;
            // 
            // rbNetball
            // 
            rbNetball.AutoSize = true;
            rbNetball.Font = new Font("Cambria", 11.25F, FontStyle.Bold);
            rbNetball.Location = new Point(47, 244);
            rbNetball.Name = "rbNetball";
            rbNetball.Size = new Size(77, 21);
            rbNetball.TabIndex = 2;
            rbNetball.Text = "NetBall";
            rbNetball.UseVisualStyleBackColor = true;
            rbNetball.CheckedChanged += rbNetball_CheckedChanged;
            // 
            // rbSwimming
            // 
            rbSwimming.AutoSize = true;
            rbSwimming.Font = new Font("Cambria", 11.25F, FontStyle.Bold);
            rbSwimming.Location = new Point(47, 295);
            rbSwimming.Name = "rbSwimming";
            rbSwimming.Size = new Size(99, 21);
            rbSwimming.TabIndex = 3;
            rbSwimming.Text = "Swimming";
            rbSwimming.UseVisualStyleBackColor = true;
            rbSwimming.CheckedChanged += rbSwimming_CheckedChanged;
            // 
            // rbRunning
            // 
            rbRunning.AutoSize = true;
            rbRunning.Font = new Font("Cambria", 11.25F, FontStyle.Bold);
            rbRunning.Location = new Point(47, 340);
            rbRunning.Name = "rbRunning";
            rbRunning.Size = new Size(85, 21);
            rbRunning.TabIndex = 4;
            rbRunning.Text = "Running";
            rbRunning.UseVisualStyleBackColor = true;
            rbRunning.CheckedChanged += rbRunning_CheckedChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(207, 149);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(367, 210);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Cambria", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(166, 52);
            label1.Name = "label1";
            label1.Size = new Size(300, 34);
            label1.TabIndex = 6;
            label1.Text = "Youth Sport Selection";
            // 
            // lblMessage
            // 
            lblMessage.AutoSize = true;
            lblMessage.Font = new Font("Cambria", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblMessage.Location = new Point(222, 380);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(141, 19);
            lblMessage.TabIndex = 7;
            lblMessage.Text = "Select Your Sport!!";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(600, 405);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 8;
            button1.Text = "exit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // btnClear
            // 
            btnClear.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClear.Location = new Point(600, 365);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(75, 23);
            btnClear.TabIndex = 9;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += button2_Click;
            // 
            // rbVolleyball
            // 
            rbVolleyball.AutoSize = true;
            rbVolleyball.Font = new Font("Cambria", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rbVolleyball.Location = new Point(47, 381);
            rbVolleyball.Name = "rbVolleyball";
            rbVolleyball.Size = new Size(98, 21);
            rbVolleyball.TabIndex = 10;
            rbVolleyball.TabStop = true;
            rbVolleyball.Text = "VolleyBall";
            rbVolleyball.UseVisualStyleBackColor = true;
            rbVolleyball.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // YouthSport
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.background;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(687, 450);
            Controls.Add(rbVolleyball);
            Controls.Add(btnClear);
            Controls.Add(button1);
            Controls.Add(lblMessage);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(rbRunning);
            Controls.Add(rbSwimming);
            Controls.Add(rbNetball);
            Controls.Add(rbSoccer);
            Controls.Add(rbBasketball);
            DoubleBuffered = true;
            Name = "YouthSport";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void rbVolleyBall_CheckedChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private RadioButton rbBasketball;
        private RadioButton rbSoccer;
        private RadioButton rbNetball;
        private RadioButton rbSwimming;
        private RadioButton rbRunning;
        private PictureBox pictureBox1;
        private Label label1;
        private Label lblMessage;
        private Button button1;
        private Button btnClear;
        private RadioButton rbVolleyball;
    }
}
