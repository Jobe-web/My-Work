namespace YouthSportSignUp
{
    public partial class YouthSport : Form
    {
        public YouthSport()
        {
            InitializeComponent();
        }



        private void UpdateSelection()
        {
            if (rbBasketball.Checked)
            {
                lblMessage.Text = "Don't forget to bring your basketball shoes!";
                pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\image\\Basketball.jpg");
            }
            else if (rbSoccer.Checked)
            {
                lblMessage.Text = "Don't forget to bring your soccer cleats!";
                pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\image\\Soccer.jpg");
            }
            else if (rbSwimming.Checked)
            {
                lblMessage.Text = "Don't forget to bring your swimming gear!";
                pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\image\\Swimming.jpg");
            }
            else if (rbNetball.Checked)
            {
                lblMessage.Text = "Don't forget to bring your netball shoes!";
                pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\image\\Netball.jpg");
            }
            else if (rbRunning.Checked)
            {
                lblMessage.Text = "Don't forget to bring your running shoes!";
                pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\image\\Running.jpg");
            }
            else if (rbVolleyball.Checked)
            {
                lblMessage.Text = "Don't forget to bring your volleyball shoes!";
                pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\image\\Volleyball.jpg");
            }
            // else
            //{
            //    lblMessage.Text = "Please select a sport";
            //    pictureBox1.Image = null;
            //}
        }
        private void rbBasketball_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelection();
        }

        private void rbSoccer_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelection();
        }

        private void rbNetball_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelection();
        }

        private void rbSwimming_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelection();
        }

        private void rbRunning_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelection();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            rbBasketball.Checked = false;
            rbSoccer.Checked = false;
            rbSwimming.Checked = false;
            rbNetball.Checked = false;
            rbRunning.Checked = false;
            rbVolleyball.Checked = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ShowGif()
        {
            pictureBox1.Image = null; // clear current image

            pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\image\\sport.gif");

            lblMessage.Text = "Please select a sport";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            rbBasketball.Checked = false;
            rbSoccer.Checked = false;
            rbSwimming.Checked = false;
            rbNetball.Checked = false;
            rbRunning.Checked = false;
            rbVolleyball.Checked = false;
            ShowGif();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateSelection();
        }
    }
}
