﻿namespace Bag_Order_Form__With_Shipping___Pricing_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstStyles = new ListBox();
            cmbQuantity = new ComboBox();
            btnCalculate = new Button();
            btnClear = new Button();
            rbOvernight = new RadioButton();
            rbThreeDay = new RadioButton();
            rbStandard = new RadioButton();
            SuspendLayout();
            // 
            // lstStyles
            // 
            lstStyles.FormattingEnabled = true;
            lstStyles.ItemHeight = 15;
            lstStyles.Location = new Point(47, 43);
            lstStyles.Name = "lstStyles";
            lstStyles.Size = new Size(120, 94);
            lstStyles.TabIndex = 0;
            // 
            // cmbQuantity
            // 
            cmbQuantity.FormattingEnabled = true;
            cmbQuantity.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            cmbQuantity.Location = new Point(196, 43);
            cmbQuantity.Name = "cmbQuantity";
            cmbQuantity.Size = new Size(213, 23);
            cmbQuantity.TabIndex = 1;
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(196, 83);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(75, 23);
            btnCalculate.TabIndex = 2;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(321, 83);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(75, 23);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // rbOvernight
            // 
            rbOvernight.AutoSize = true;
            rbOvernight.Location = new Point(457, 43);
            rbOvernight.Name = "rbOvernight";
            rbOvernight.Size = new Size(78, 19);
            rbOvernight.TabIndex = 4;
            rbOvernight.TabStop = true;
            rbOvernight.Text = "Overnight";
            rbOvernight.UseVisualStyleBackColor = true;
            // 
            // rbThreeDay
            // 
            rbThreeDay.AutoSize = true;
            rbThreeDay.Location = new Point(457, 83);
            rbThreeDay.Name = "rbThreeDay";
            rbThreeDay.Size = new Size(75, 19);
            rbThreeDay.TabIndex = 6;
            rbThreeDay.TabStop = true;
            rbThreeDay.Text = "ThreeDay";
            rbThreeDay.UseVisualStyleBackColor = true;
            // 
            // rbStandard
            // 
            rbStandard.AutoSize = true;
            rbStandard.Location = new Point(457, 119);
            rbStandard.Name = "rbStandard";
            rbStandard.Size = new Size(72, 19);
            rbStandard.TabIndex = 7;
            rbStandard.TabStop = true;
            rbStandard.Text = "Standard";
            rbStandard.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(rbStandard);
            Controls.Add(rbThreeDay);
            Controls.Add(rbOvernight);
            Controls.Add(btnClear);
            Controls.Add(btnCalculate);
            Controls.Add(cmbQuantity);
            Controls.Add(lstStyles);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lstStyles;
        private ComboBox cmbQuantity;
        private Button btnCalculate;
        private Button btnClear;
        private RadioButton rbOvernight;
        private RadioButton rbThreeDay;
        private RadioButton rbStandard;
    }
}
