namespace Bag_Order_Form__With_Shipping___Pricing_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            lstStyles.Sorted = true;

            lstStyles.Items.Add("Beaded - $45.00");
            lstStyles.Items.Add("Fringed - $25.00");
            lstStyles.Items.Add("Full Decorative - $50.00");
            lstStyles.Items.Add("Leather - $80.00");
            lstStyles.Items.Add("Plain - $20.00");
            lstStyles.Items.Add("Pirate Design - $40.00");

            for (int i = 1; i <= 10; i++)
            {
                cmbQuantity.Items.Add(i);
            }

            cmbQuantity.SelectedIndex = 0;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (lstStyles.SelectedItem == null)
            {
                MessageBox.Show("Please select a bag style!");
                return;
            }

            if (cmbQuantity.SelectedItem == null)
            {
                MessageBox.Show("Please select quantity!");
                return;
            }

            if (!rbOvernight.Checked && !rbThreeDay.Checked && !rbStandard.Checked)
            {
                MessageBox.Show("Please select shipping option!");
                return;
            }

            string item = lstStyles.SelectedItem.ToString();
            int qty = Convert.ToInt32(cmbQuantity.SelectedItem);

            // Get price from string
            string priceText = item.Substring(item.IndexOf('$') + 1);
            double price = Convert.ToDouble(priceText);

            double subtotal = price * qty;

            double rate = 0;

            if (rbOvernight.Checked)
                rate = 0.10;
            else if (rbThreeDay.Checked)
                rate = 0.07;
            else if (rbStandard.Checked)
                rate = 0.05;

            double shipping = subtotal * rate;
            double total = subtotal + shipping;

            MessageBox.Show(
                "ITEM: " + item +
                "\nQUANTITY: " + qty +
                "\nSUBTOTAL: $" + subtotal.ToString("0.00") +
                "\nSHIPPING: $" + shipping.ToString("0.00") +
                "\nTOTAL: $" + total.ToString("0.00"),
                "ORDER SUMMARY",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstStyles.ClearSelected();
            cmbQuantity.SelectedIndex = 0;

            rbOvernight.Checked = false;
            rbThreeDay.Checked = false;
            rbStandard.Checked = false;
        }
    }
}
