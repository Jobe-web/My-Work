﻿namespace Bag_Order
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstStyles = new ListBox();
            cmbQuantity = new ComboBox();
            btnSelect = new Button();
            btnClear = new Button();
            SuspendLayout();
            // 
            // lstStyles
            // 
            lstStyles.FormattingEnabled = true;
            lstStyles.ItemHeight = 15;
            lstStyles.Items.AddRange(new object[] { "Full Decorative", "", "Beaded", "", "Pirate Design", "", "Fringed", "", "Leather", "", "Plain" });
            lstStyles.Location = new Point(32, 37);
            lstStyles.Name = "lstStyles";
            lstStyles.Size = new Size(120, 94);
            lstStyles.TabIndex = 0;
            // 
            // cmbQuantity
            // 
            cmbQuantity.FormattingEnabled = true;
            cmbQuantity.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
            cmbQuantity.Location = new Point(186, 37);
            cmbQuantity.Name = "cmbQuantity";
            cmbQuantity.Size = new Size(215, 23);
            cmbQuantity.TabIndex = 1;
            // 
            // btnSelect
            // 
            btnSelect.Location = new Point(197, 85);
            btnSelect.Name = "btnSelect";
            btnSelect.Size = new Size(75, 23);
            btnSelect.TabIndex = 2;
            btnSelect.Text = "Select";
            btnSelect.UseVisualStyleBackColor = true;
            btnSelect.Click += btnSelect_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(326, 85);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(75, 23);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnClear);
            Controls.Add(btnSelect);
            Controls.Add(cmbQuantity);
            Controls.Add(lstStyles);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private ListBox lstStyles;
        private ComboBox cmbQuantity;
        private Button btnSelect;
        private Button btnClear;
    }
}
