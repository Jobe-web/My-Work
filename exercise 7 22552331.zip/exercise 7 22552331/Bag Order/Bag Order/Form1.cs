namespace Bag_Order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (lstStyles.SelectedItem == null)
            {
                MessageBox.Show("Please select a bag style!",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (cmbQuantity.SelectedItem == null)
            {
                MessageBox.Show("Please select quantity!",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string style = lstStyles.SelectedItem.ToString();
            string qty = cmbQuantity.SelectedItem.ToString();

            MessageBox.Show(
                "You selected:\nStyle: " + style + "\nQuantity: " + qty,
                "Order Confirmation",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstStyles.ClearSelected();
            cmbQuantity.SelectedIndex = -1; // clears ComboBox selection
        }
    }
}
