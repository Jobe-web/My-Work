import java.util.*;

public class Salary
{
   public static void main(String[] args)
   {
      Scanner in =new Scanner(System.in);
      double payRate, regularHours, overTimeHours;
      
      System.out.println("Enter the pay rate");
      payRate=in.nextDouble();
      
      System.out.println("Enter the regular hours");
      regularHours=in.nextDouble();
      
      System.out.println("Enter the overTimeHours");
      overTimeHours=in.nextDouble();
      double overTimePay= calculate(payRate, regularHours, overTimeHours);
      System.out.print("The over time pay is: " + overTimePay);
      
   }
   public static double calculate(double payRate, double regularHours, double overTimeHours)
   {
      double overTimePay = regularHours * payRate + overTimeHours * 1.5 * payRate;
         
      return overTimePay;
   }
}