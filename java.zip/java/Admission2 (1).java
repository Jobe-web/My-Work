import java.util.*;
public class Admission2
{
   public static void main(String[] args)
   {
      Scanner in=new Scanner(System.in);
      double average;
      int testScore;
      System.out.println("enter your test score: ");
      testScore=in.nextInt();
      System.out.println("Enter your grade average: ");
      average=in.nextDouble();
      
      if (testScore >= 60 && average >= 3.0)
      {  
         System.out.println("you are accepted at college");
      }
      else if (testScore >= 80 && average <= 3.0)
      {
         System.out.println("you are Accepted at college");
      }
      else if (testScore < 60 && average < 3.0)
      {
         System.out.println("you are Rejected at college");
      }
      else if (testScore < 0 || testScore > 100 || average < 0 || average > 4.0)
      {
         System.out.println("An error has occur "); 
      }
   }
}