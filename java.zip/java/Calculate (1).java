import java.util.*;
public class Calculate
{
   public static void main(String[] args)
   {
      Scanner in=new Scanner(System.in);
      System.out.println("Enter the first integer: ");
      int num1=in.nextInt();
      System.out.println("Enter the second integer: ");
      int num2=in.nextInt();
      
      System.out.println("1 - Add the two integers");
      System.out.println("2 - Subtract the second integer from the first integer");
      System.out.println("3 - Multiply the integers");
      System.out.println("4 - Divide the first integer by the second integer");
      System.out.println("select a choice (1-4)");
      int choice=in.nextInt(); 
      
      int Addition;
      int Subtraction;
      int Multiplication;
      int Division;
      
      if (choice == 1)
      {
         Addition = num1 + num2;
         System.out.println("The addition is equal to: " + Addition);
      }
      else if (choice == 2)
      {
         Subtraction = num2 - num1;
         System.out.println("The subtraction is equal to: " + Subtraction);
      }
      else if (choice == 3)
      {
         Multiplication = num1 * num2;
         System.out.println("The multiplication is equal to: " + Multiplication);
      }
      else if (choice <= 0 || choice > 4 )
      {
         System.out.println("An error has occur");
      }    
      else if (choice == 4 && num2 ==0)
      {
         System.out.println("An error has occur");
      }
      else
      {
         Division = num1/num2;
         System.out.println("The division is equal to: " + Division);
      }
   }
} 
      
      