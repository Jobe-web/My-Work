import javax.swing.*;
public class Balance2
{
   public static void main(String[] args)
   {
      // ask the user to input the checking account balance
     String input = JOptionPane.showInputDialog( "input the checkingAccBalance");
      double checkingAccBalance= Double.parseDouble(input);
      
      // ask the user to input the savings account balance
      String input2 = JOptionPane.showInputDialog("input the savings account balance");
      double savingsAccBalance = Double.parseDouble(input2);
      
      // check if the checkingAccbalance is low
      if (checkingAccBalance < 10)
      {
         JOptionPane.showMessageDialog(null, "The checking account balance is low");
         }
     
     // check if the savingsAccBalance is low
      if (savingsAccBalance < 100)
      {
         JOptionPane.showMessageDialog(null, "The savings account balance is low");
         }
         
         //check if both are dangerously low
         if (checkingAccBalance < 10 && savingsAccBalance < 100)
         {
         JOptionPane.showMessageDialog(null, "Both account dangerously low");
         }
   }
}  

      
