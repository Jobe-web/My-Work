import java.util.*;
public class furniture
{
   public static void main(String[] args)
   {
      Scanner in= new Scanner(System.in);
      
      System.out.println("choose the type of the wood you like:");
      System.out.println("1-pine ($100)");
      System.out.println("2-oak ($225)");
      System.out.println("3-mahogany ($310)");
      System.out.println("Enter you choice from 1,2 and 3");
   
      int choice = in.nextInt();    
      if (choice == 1) 
      {
         String woodType = "pane";
         int price =  100;
       
      }else if (choice == 2)
      {
         String woodType = "oak";
         int price =  225;
       
      } else if (choice == 3) {
         String woodType = "mahogany";
         int price = 310;
      }else {
      String woodType = "invalid choice";
      int price = 0;
      }
      System.out.println("wood selected " + woodType); 
      System.out.println("price of the table " + price); 
   }
}   
       
