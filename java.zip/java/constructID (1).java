import javax.swing.*;
public class constructID
{
   public static void main(String[] args)
   {
   
      String str;
      str=JOptionPane.showInputDialog(null, "Write your fullname and street address");
   
      String words=str.trim();
      int count=0;
      int id=0;
      String initials="";
   
      for(String word: words.split("\\s+"))
      {
         count++;
         if(count < 4)
         {
            initials += Character.toUpperCase(word.charAt(0));
           }
           else if(count==4)
            {
                id=Integer.parseInt(word);
            }
         
      }
      String yourID= initials + id;
      JOptionPane.showMessageDialog(null, yourID );
   }
}

   
