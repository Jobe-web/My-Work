import java.util.*;
public class Interest
{
   public static void main(String[] args)
   {
      Scanner in= new Scanner(System.in);
      double investment;
      
      System.out.println("Enter the starting investment ");
      investment=in.nextDouble();
      double totalMoney= calculate(investment) + investment;
      System.out.print("The total money that the user will have is: " + totalMoney);
      }
      
      public static double calculate(double investment)
      {
         double AmountOfMoney= investment * 0.5;
         double totalMoney= AmountOfmoney + investment;
         
         
         return totalMoney;
         }
       }  
