import java.util.*;
public class even
{
   public static void main(String[] args)
   {
      int num;
      num = 2;
      
      while (num <= 100)
      {
         if (num%20==0)
            System.out.println("\t" + num);
         else
            System.out.print("\t" + num);
            num = num + 2;
      }
   }
}
         

