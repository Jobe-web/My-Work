import java.util.*;
public class Calculator
{
   public static void main(String[] args)
   {
      Scanner in= new Scanner(System.in);
      double price, commissionRate, discountRate;
      
      System.out.println("Enter the price ");
      price=in.nextDouble();
      System.out.println("Enter the commission Rate");
      commissionRate=in.nextDouble();
      System.out.println("Enter the discount Rate");
      discountRate=in.nextDouble();
      double finalPrice = calculatePrice(price, commissionRate, discountRate);
      System.out.print("The final price is: " + finalPrice);
      
   
     }
     public static double calculatePrice(double price, double commissionRate, double discountRate )
     {
     double commissionAmount = price * (commissionRate / 100);
      double totalPrice = price + commissionAmount;
      double discountAmount = totalPrice * (discountRate / 100);
      double finalPrice = totalPrice + discountAmount;
      
      return finalPrice;
        }
    }  
      
      