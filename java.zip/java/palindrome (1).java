import java.util.*;
public class palindrome
{
   public static void main(String args[])
   {
   
   Scanner kb=new Scanner(System.in);
   
   String reversed="";
  System.out.println("Enter the phrase:");
  String name=kb.nextLine();
  
  int sb=name.length();
  
  for(int i=sb-1; i>=0; i--)
  {
  reversed+=name.charAt(i);// + reversed;
  }
  if(name.equalsIgnoreCase(reversed))
  {
  
  System.out.println("The phrase " + name + " is a palindrome");
  }
  else 
  {
   System.out.println("The phrase " + name + " is not a palindrome");
   }
   }
  }