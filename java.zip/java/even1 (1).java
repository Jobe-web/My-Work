import java.util.*;
public class even1
{
   public static void main(String[] args)
   {
      int num;
      
      for (num = 2; num <= 100; num = num + 2)
      {
         if (num%20==0)
            System.out.println("\t" + num);
         else
            System.out.print("\t" + num);
      }
   }
}
