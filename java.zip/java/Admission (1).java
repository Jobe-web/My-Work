import java.util.*;
public class Admission
{
   public static void main(String[] args)
   {
      Scanner in=new Scanner(System.in);
      double average;
      int testScore;
      System.out.println("enter your test score: ");
      testScore=in.nextInt();
      System.out.println("Enter your grade average: ");
      average=in.nextDouble();
      
      if (testScore >= 60 && average >= 3.0)
      {  
         System.out.println("you are Accepted at college");
      } else if (testScore >= 80 && average <= 3.0)
      {
         System.out.println("you are Accepted at college");
      } else {
         System.out.println("you are Rejected at college");
      }
   }
}