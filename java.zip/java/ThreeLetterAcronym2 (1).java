import java.util.*;
public class ThreeLetterAcronym2
{
   public static void main(String[]args)
   {
   String word, acronym= null;
   char achar, acr;
   int len;
   
   Scanner kb = new Scanner(System.in);
   System.out.println("Please enter three words");
   word = kb.nextLine();
   word = word.toUpperCase();
   len = word.length();
   
   acr = word.charAt(0);
   //acronym = Character.toString(acr);
   acronym = "" + acr;
   for ( int i= 0; i<len ;i++)
   {
   achar = word.charAt(i);
   if (Character.isWhitespace(achar))
       {
         acronym = acronym + word.charAt(i+1);
         
       }
   
   }
   
   System.out.println("The original phrase is : "+word+"\n and the acronym is : "+acronym);
   }
}