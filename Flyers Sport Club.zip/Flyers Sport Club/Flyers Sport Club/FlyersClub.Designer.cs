﻿namespace Flyers_Sport_Club
{
    partial class FlyersClub
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            chbSnowGloves = new CheckBox();
            chbSkis = new CheckBox();
            chbGoggles = new CheckBox();
            chbearmuffs = new CheckBox();
            chbSnowBoots = new CheckBox();
            button1 = new Button();
            label1 = new Label();
            pnlDisplay = new Panel();
            lblSnowGloves = new Label();
            lblSkis = new Label();
            lblEarmuffs = new Label();
            lblGoggles = new Label();
            lblSnowBoots = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            button2 = new Button();
            tabPage2 = new TabPage();
            label2 = new Label();
            btnSelect = new Button();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            displayOrderToolStripMenuItem = new ToolStripMenuItem();
            clearToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            label3 = new Label();
            pnlDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // chbSnowGloves
            // 
            chbSnowGloves.AutoSize = true;
            chbSnowGloves.Location = new Point(112, 83);
            chbSnowGloves.Name = "chbSnowGloves";
            chbSnowGloves.Size = new Size(93, 19);
            chbSnowGloves.TabIndex = 0;
            chbSnowGloves.Text = "Snow Gloves";
            chbSnowGloves.UseVisualStyleBackColor = true;
            // 
            // chbSkis
            // 
            chbSkis.AutoSize = true;
            chbSkis.Location = new Point(112, 212);
            chbSkis.Name = "chbSkis";
            chbSkis.Size = new Size(46, 19);
            chbSkis.TabIndex = 1;
            chbSkis.Text = "Skis";
            chbSkis.UseVisualStyleBackColor = true;
            // 
            // chbGoggles
            // 
            chbGoggles.AutoSize = true;
            chbGoggles.Location = new Point(527, 108);
            chbGoggles.Name = "chbGoggles";
            chbGoggles.Size = new Size(69, 19);
            chbGoggles.TabIndex = 2;
            chbGoggles.Text = "Goggles";
            chbGoggles.UseVisualStyleBackColor = true;
            // 
            // chbearmuffs
            // 
            chbearmuffs.AutoSize = true;
            chbearmuffs.Location = new Point(112, 307);
            chbearmuffs.Name = "chbearmuffs";
            chbearmuffs.Size = new Size(73, 19);
            chbearmuffs.TabIndex = 3;
            chbearmuffs.Text = "earmuffs";
            chbearmuffs.UseVisualStyleBackColor = true;
            // 
            // chbSnowBoots
            // 
            chbSnowBoots.AutoSize = true;
            chbSnowBoots.Location = new Point(527, 244);
            chbSnowBoots.Name = "chbSnowBoots";
            chbSnowBoots.Size = new Size(87, 19);
            chbSnowBoots.TabIndex = 4;
            chbSnowBoots.Text = "snow boots";
            chbSnowBoots.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(353, 372);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 6;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Cambria", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(100, 21);
            label1.Name = "label1";
            label1.Size = new Size(312, 32);
            label1.TabIndex = 7;
            label1.Text = "WELCOME TO  GUBASI'S";
            // 
            // pnlDisplay
            // 
            pnlDisplay.Controls.Add(lblSnowGloves);
            pnlDisplay.Controls.Add(lblSkis);
            pnlDisplay.Controls.Add(lblEarmuffs);
            pnlDisplay.Controls.Add(lblGoggles);
            pnlDisplay.Controls.Add(lblSnowBoots);
            pnlDisplay.Location = new Point(252, 74);
            pnlDisplay.Name = "pnlDisplay";
            pnlDisplay.Size = new Size(226, 256);
            pnlDisplay.TabIndex = 15;
            pnlDisplay.Paint += pnlDisplay_Paint;
            // 
            // lblSnowGloves
            // 
            lblSnowGloves.AutoSize = true;
            lblSnowGloves.Location = new Point(9, 9);
            lblSnowGloves.Name = "lblSnowGloves";
            lblSnowGloves.Size = new Size(0, 15);
            lblSnowGloves.TabIndex = 22;
            // 
            // lblSkis
            // 
            lblSkis.AutoSize = true;
            lblSkis.Location = new Point(9, 47);
            lblSkis.Name = "lblSkis";
            lblSkis.Size = new Size(0, 15);
            lblSkis.TabIndex = 23;
            lblSkis.Click += lblSkis_Click;
            // 
            // lblEarmuffs
            // 
            lblEarmuffs.AutoSize = true;
            lblEarmuffs.Location = new Point(9, 96);
            lblEarmuffs.Name = "lblEarmuffs";
            lblEarmuffs.Size = new Size(0, 15);
            lblEarmuffs.TabIndex = 24;
            // 
            // lblGoggles
            // 
            lblGoggles.AutoSize = true;
            lblGoggles.Location = new Point(9, 138);
            lblGoggles.Name = "lblGoggles";
            lblGoggles.Size = new Size(0, 15);
            lblGoggles.TabIndex = 25;
            // 
            // lblSnowBoots
            // 
            lblSnowBoots.AutoSize = true;
            lblSnowBoots.Location = new Point(9, 179);
            lblSnowBoots.Name = "lblSnowBoots";
            lblSnowBoots.Size = new Size(0, 15);
            lblSnowBoots.TabIndex = 26;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.snow_gloves1;
            pictureBox1.Location = new Point(6, 46);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.earmuffs;
            pictureBox2.Location = new Point(6, 282);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 77);
            pictureBox2.TabIndex = 17;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.skis;
            pictureBox3.Location = new Point(6, 166);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 97);
            pictureBox3.TabIndex = 18;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.goggles;
            pictureBox4.Location = new Point(620, 74);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(100, 92);
            pictureBox4.TabIndex = 19;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.snow_boots;
            pictureBox5.Location = new Point(620, 195);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(100, 131);
            pictureBox5.TabIndex = 20;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.snow_fun;
            pictureBox6.Location = new Point(153, 56);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(202, 268);
            pictureBox6.TabIndex = 21;
            pictureBox6.TabStop = false;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(12, 12);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(746, 429);
            tabControl1.TabIndex = 22;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(button2);
            tabPage1.Controls.Add(pictureBox6);
            tabPage1.Controls.Add(label1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(738, 401);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "homePage";
            tabPage1.UseVisualStyleBackColor = true;
            tabPage1.Click += tabPage1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(463, 175);
            button2.Name = "button2";
            button2.Size = new Size(100, 23);
            button2.TabIndex = 22;
            button2.Text = "Go Select";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label2);
            tabPage2.Controls.Add(btnSelect);
            tabPage2.Controls.Add(pictureBox1);
            tabPage2.Controls.Add(pnlDisplay);
            tabPage2.Controls.Add(pictureBox5);
            tabPage2.Controls.Add(chbSnowGloves);
            tabPage2.Controls.Add(chbSnowBoots);
            tabPage2.Controls.Add(pictureBox4);
            tabPage2.Controls.Add(pictureBox3);
            tabPage2.Controls.Add(pictureBox2);
            tabPage2.Controls.Add(chbGoggles);
            tabPage2.Controls.Add(chbSkis);
            tabPage2.Controls.Add(chbearmuffs);
            tabPage2.Controls.Add(menuStrip1);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(738, 401);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Selection";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Cambria", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(252, 30);
            label2.Name = "label2";
            label2.Size = new Size(208, 25);
            label2.TabIndex = 21;
            label2.Text = "Pick What You Want";
            // 
            // btnSelect
            // 
            btnSelect.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSelect.Location = new Point(315, 349);
            btnSelect.Name = "btnSelect";
            btnSelect.Size = new Size(75, 23);
            btnSelect.TabIndex = 0;
            btnSelect.Text = "Select";
            btnSelect.UseVisualStyleBackColor = true;
            btnSelect.Click += btnSelect_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem });
            menuStrip1.Location = new Point(3, 3);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(732, 24);
            menuStrip1.TabIndex = 22;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { displayOrderToolStripMenuItem, clearToolStripMenuItem, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "File";
            // 
            // displayOrderToolStripMenuItem
            // 
            displayOrderToolStripMenuItem.Name = "displayOrderToolStripMenuItem";
            displayOrderToolStripMenuItem.Size = new Size(145, 22);
            displayOrderToolStripMenuItem.Text = "Display Order";
            displayOrderToolStripMenuItem.Click += displayOrderToolStripMenuItem_Click;
            // 
            // clearToolStripMenuItem
            // 
            clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            clearToolStripMenuItem.Size = new Size(145, 22);
            clearToolStripMenuItem.Text = "Clear";
            clearToolStripMenuItem.Click += clearToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(145, 22);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 11.25F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.Location = new Point(463, 142);
            label3.Name = "label3";
            label3.Size = new Size(198, 17);
            label3.TabIndex = 23;
            label3.Text = "To Select items  Click below :";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(757, 443);
            Controls.Add(tabControl1);
            Controls.Add(button1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            pnlDisplay.ResumeLayout(false);
            pnlDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private CheckBox chbSnowGloves;
        private CheckBox chbSkis;
        private CheckBox chbGoggles;
        private CheckBox chbearmuffs;
        private CheckBox chbSnowBoots;
        private Button button1;
        private Label label1;
        private Panel pnlDisplay;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label label2;
        private Button btnSelect;
        private Label lblSnowGloves;
        private Label lblSkis;
        private Label lblEarmuffs;
        private Label lblGoggles;
        private Label lblSnowBoots;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem displayOrderToolStripMenuItem;
        private ToolStripMenuItem clearToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private Button button2;
        private Label label3;
    }
}
