using System.Drawing;
using System.Windows.Forms;
namespace Flyers_Sport_Club
{
    public partial class FlyersClub : Form
    {
        public FlyersClub()
        {
            InitializeComponent();
            tabPage2.Enabled = false;
        }

        private void pnlDisplay_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (chbSnowGloves.Checked)
            {
                lblSnowGloves.Text = "Snow Gloves: R200";
            }
            if (chbSkis.Checked)
            {
                lblSkis.Text = "Skis: R600";
            }
            if (chbearmuffs.Checked)
            {
                lblEarmuffs.Text = "Earmuffs: R150";
            }
            if (chbGoggles.Checked)
            {
                lblGoggles.Text = "Goggles: R460";
            }
            if (chbSnowBoots.Checked)
            {
                lblSnowBoots.Text = "Snow Boots: R900";
            }
            if (!chbSnowGloves.Checked && !chbSkis.Checked && !chbearmuffs.Checked && !chbGoggles.Checked && !chbSnowBoots.Checked)
            {
                MessageBox.Show("Please select at least one item.");
            }
        }

        private void displayOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string order = "Selected items:\n";
            int totalCost = 0;

            if (chbSnowGloves.Checked)
            {
                order += "- Snow Gloves: R200\n";
                totalCost += 200;
            }
            if (chbSkis.Checked)
            {
                order += "- Skis: R600\n";
                totalCost += 600;
            }
            if (chbearmuffs.Checked)
            {
                order += "- Earmuffs: R150\n";
                totalCost += 150;
            }
            if (chbGoggles.Checked)
            {
                order += "- Goggles: R460\n";
                totalCost += 460;
            }
            if (chbSnowBoots.Checked)
            {
                order += "- Snow Boots: R900\n";
                totalCost += 900;
            }
            if (totalCost == 0)
            {
                MessageBox.Show("No items selected.");
                return;
            }

            order += "\nTotal Cost: R" + totalCost;
            MessageBox.Show(order);
            MessageBox.Show("Thank you for your order!");
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            chbSnowGloves.Checked = false;
            chbSkis.Checked = false;
            chbearmuffs.Checked = false;
            chbGoggles.Checked = false;
            chbSnowBoots.Checked = false;
            lblEarmuffs.Text = "";
            lblGoggles.Text = "";
            lblSkis.Text = "";
            lblSnowBoots.Text = "";
            lblSnowGloves.Text = "";
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabPage2.Enabled = true;
            tabControl1.SelectedTab = tabPage2;
            tabPage1.Enabled = false;
        }

        private void lblSkis_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

            
        }
    }
}
