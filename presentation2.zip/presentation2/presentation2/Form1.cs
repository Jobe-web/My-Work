using ReadingMateria;

namespace presentation2
{
    public partial class Form1 : Form
    {
        public Magazine mag;
        public Book book;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtAuthor.Text = mag.Auther;
            txtTitle.Text = mag.Title;
            txtLoc.Text = mag.GetHardCopyForm();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mag = new Magazine("Zora Neale Hurston", "Opportunity: A Journal of Negro Life");
            book = new Book("Felix Dennis", "How to Get Rich");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtAuthor.Text = book.Auther;
            txtTitle.Text = book.Title;
            txtLoc.Text = book.GetHardCopyForm();

        }
    }
}
