﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ReadingMateria.ReadingMateria;

namespace ReadingMateria
{
    public class Magazine : ReadingMateria, IPrintable
    {
        public Magazine(string aut, string title) 
            : base(aut, title)
        {
        }
        public string GetHardCopyForm()
        {
            return "Available as a printable PDF";
        }
    }
}
