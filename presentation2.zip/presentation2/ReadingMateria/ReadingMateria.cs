﻿namespace ReadingMateria
{
    public class ReadingMateria
    {
        protected string auther;
        protected string title;

        public ReadingMateria(string aut, string title)
        {
            auther = aut;
            this.title = title;
        }

        public string Auther
        {
            get
            {
                return auther;
            }
            set
            {
                auther = value;
            }
        }

        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }
        public interface IPrintable
        {
            string GetHardCopyForm();
        }
    }
}
