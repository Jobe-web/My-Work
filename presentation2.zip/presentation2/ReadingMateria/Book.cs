﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ReadingMateria.ReadingMateria;

namespace ReadingMateria
{
    public class Book : ReadingMateria, IPrintable
    {
        public Book(string aut, string title)
            : base(aut, title)
        {
        }

        public string GetHardCopyForm()
        {
            return "Available in the bookStore";
        }
    }
}
